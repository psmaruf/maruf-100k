<p align="center">
  <img src="https://i.imgur.com/4Ldttfr.jpeg" width="250" style="border-radius: 15px;" alt="RAHAD BOT DP" />
</p>

<h1 align="center">
  🔧💥 PS MARUF GAMING  💥🔧
</h1>

<h3 align="center">
  🧠 𝙋𝙀𝙍𝙎𝙊𝙉𝘼𝙇 𝙈𝙀𝙎𝙎𝙀𝙉𝙂𝙀𝙍 𝘽𝙊𝙏 𝘽𝙐𝙄𝙇𝙏 𝘽𝙔 ✨ <b>𝑹𝑨𝑯𝑨𝑫</b>
</h3>

<p align="center">
  <img src="https://img.shields.io/badge/MADE_BY-RAHAD-red?style=for-the-badge" />
  <img src="https://img.shields.io/badge/COUNTRY-BANGLADESH-0088ff?style=for-the-badge" />
  <img src="https://img.shields.io/badge/LEVEL-NOOB_PRO_DEV-blueviolet?style=for-the-badge" />
</p>

---

<p align="center">
  🌈✨ <b><i>𝙒𝙀𝙇𝘾𝙊𝙈𝙀 𝙏𝙊 𝙍𝘼𝙃𝘼𝘿 -𝙓𝘼𝙎𝙎 𝘽𝙊𝙏</i></b> ✨🌈<br>
  🤖 𝘾𝙪𝙨𝙩𝙤𝙢 | ⚙️ 𝙁𝙖𝙨𝙩 | 🧠 𝙎𝙢𝙖𝙧𝙩 | 🎭 𝙁𝙪𝙣 | 🔐 𝙎𝙚𝙘𝙪𝙧𝙚
</p>

---

## 🧩 𝐅𝐄𝐀𝐓𝐔𝐑𝐄𝐒:

```yaml
✅ Auto Command & Prefix System
🎥 Media/Video Reply Handler
🌍 Multi-Language Support
🧠 AI-Powered Message Logic
🎨 Stylish Emoji + Font Messages
🔐 Anti-Crash Mode Enabled
💬 24/7 Group Chat Responder
