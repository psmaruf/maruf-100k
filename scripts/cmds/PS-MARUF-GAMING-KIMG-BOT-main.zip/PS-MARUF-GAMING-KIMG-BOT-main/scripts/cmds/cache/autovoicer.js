Dummy MP3 content
