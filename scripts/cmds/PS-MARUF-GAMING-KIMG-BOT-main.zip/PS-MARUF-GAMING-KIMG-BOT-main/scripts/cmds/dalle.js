const fs = require("fs-extra");
const axios = require("axios");
const path = require("path");

const cookie = ""; // Enter _U value.
const auth = ""; // Enter KievRPSSecAuth value.

module.exports = {
  config: {
    name: "dalle",
    version: "1.0",
    author: "rehat--",
    role: 0,
    countDown: 0,
    longDescription: {
      en: "Generate unique and captivating images using DALL-E 3"
    },
    category: "ai",
    guide: {
      en: "{pn} <prompt>"
    }
  },

  onStart: async function ({ api, event, args, message }) {
    const prompt = args.join(" ");
    if (!prompt) {
      message.reply("Add something baka.");
      return;
    }
    message.reply("Please wait...⏳");

    try {
      const res = await axios.post(`https://rehatdesu.xyz/api/imagine/dalle?cookie=${cookie}&auth=${auth}&prompt=${encodeURIComponent(prompt)}`);
      const data = res.data.results.images;

      if (!data || data.length === 0) {
        message.reply("Redirect failed! Most probably bad prompt.");
        return;
      }

      const imgData = [];
      for (let i = 0; i < Math.min(4, data.length); i++) {
        const imgResponse = await axios.get(data[i].url, { responseType: 'arraybuffer' });
        const imgPath = path.join(__dirname, 'cache', `${i + 1}.jpg`);
        await fs.outputFile(imgPath, imgResponse.data);
        imgData.push(fs.createReadStream(imgPath));
      }

      await api.sendMessage({
        attachment: imgData,
      }, event.threadID, event.messageID);

    } catch (error) {
      console.error(error);
      message.reply("Redirect failed! Most probably bad prompt.");
    } finally {
      await fs.remove(path.join(__dirname, 'cache'));
    }
  }
}
