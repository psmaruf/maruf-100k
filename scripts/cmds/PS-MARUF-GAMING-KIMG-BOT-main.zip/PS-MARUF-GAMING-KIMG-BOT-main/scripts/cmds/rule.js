// file: rules.js
const axios = require("axios");
const fs = require("fs-extra");
const path = require("path");

module.exports = {
  config: {
    name: "rule",
    version: "1.1",
    author: "Cyclopean c. Blade",
    role: 0,
    shortDescription: "Show GC rules in stylish format",
    longDescription: "Display Mini Studio group rules in stylish Bangla format with attached video",
    category: "group",
    guide: "{pn}rules"
  },

  // Prefix দিয়ে রান হবে
  onStart: async function ({ message }) {
    await sendRules(message);
  },

  // No prefix দিয়ে রান হবে
  onChat: async function ({ event, message }) {
    const body = (event.body || "").toLowerCase().trim();
    const triggers = ["rule", "rules", "gc rules"];
    if (!triggers.includes(body)) return;
    await sendRules(message);
  }
};

// ---- Custom Rules Sender Function ----
async function sendRules(message) {
  const rulesDesign = `
╔═══━━━───•✧•───━━━═══╗
      🎬✨ 𝗠𝗶𝗻𝗶 𝗦𝘁𝘂𝗱𝗶𝗼 ✨🎬
     『 Vɪᴅᴇᴏ Mᴀᴋᴇ 』
        📜 𝐆𝐂 𝐑𝐮𝐥𝐞𝐬 📜
╚═══━━━───•✧•───━━━═══╝

☣️ এই গ্রুপটি শুধুমাত্র 𝑽𝒊𝒅𝒆𝒐 বানানোর জন্য  
🚫 অন্য কোনো প্রকার টেক্সট করা যাবে না  

① 🎵 𝐀𝐝𝐦𝐢𝐧 আপনাদের গান এর লাইন দিবে  
   ⤷ মেনশন করা আইডি নিজ দায়িত্বে লাইন দিবে  
   📌 লাইন দেওয়ার নিয়ম:  
      • নিজের পছন্দের পিক 📷  
      • তারপর সেই গানের লাইন 🎶

② ☢ খারাপ ছবি/ভিডিও ❌  
   ও খারাপ মন্তব্য 🚫 সম্পূর্ণ নিষিদ্ধ

③ 💬 লাইন ও পিক-এ রিঅ্যাক্ট দিতে হবে  
   🔄 রিঅ্যাক্ট না দিলে গান লাইন পাবেন না

④ ⛔ একটিভ না থাকলে  
   ⚡ না বলেই কিক করা হবে

⑤ 👑 এডমিনদের বিরুদ্ধে যাবেন না  
   💌 কোনো সমস্যা হলে এডমিনের ইনবক্সে বলুন

⑥ 🚷 কারো পিক নিয়ে মজা ❌  
   🙃 হা হা রিঅ্যাক্টও দিবেন না

⑦ 💬 আড্ডা গ্রুপ লাগলে  
   ♻️ এডমিনকে জানালে অ্যাড করে দেবে

╔═══━━━───•✧•───━━━═══╗
   💝 এই ছিলো 𝗠𝗶𝗻𝗶 𝗦𝘁𝘂𝗱𝗶𝗼 এর Rule 💝
╚═══━━━───•✧•───━━━═══╝
`;

  try {
    const videoUrl = "https://drive.google.com/uc?export=download&id=1Cj_0_JE0W6O0G1K68bYt-pAmUaX1GQKV";
    const tempPath = path.join(__dirname, "rules_video.mp4");

    // ভিডিও ডাউনলোড
    const response = await axios.get(videoUrl, { responseType: "arraybuffer" });
    fs.writeFileSync(tempPath, Buffer.from(response.data, "utf-8"));

    // মেসেজ পাঠানো
    await message.reply({
      body: rulesDesign,
      attachment: fs.createReadStream(tempPath)
    });

    // অস্থায়ী ফাইল ডিলিট
    fs.unlinkSync(tempPath);

  } catch (err) {
    console.error(err);
    await message.reply(rulesDesign + "\n\n⚠️ ভিডিও লোড করতে সমস্যা হয়েছে।");
  }
}
